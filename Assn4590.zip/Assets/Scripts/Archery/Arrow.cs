using UnityEngine;

// Arrow fired by a Bow. Flies under gravity, turns to face its velocity,
// and sticks into whatever it hits. Reports hits to any Target it strikes.
[RequireComponent(typeof(Rigidbody))]
public class Arrow : MonoBehaviour
{
    [Tooltip("Distance from the arrow's origin (nock) to its tip along +Z.")]
    public float length = 0.75f;
    public float lifetimeAfterHit = 10f;
    public float lifetimeIfMissed = 15f;
    [Tooltip("How far the arrow sinks into what it hits (meters).")]
    public float penetrationDepth = 0.08f;

    Rigidbody _rb;
    Collider[] _colliders;
    Bow _bow;
    bool _flying;
    float _destroyAt = -1f;

    void Awake()
    {
        _rb = GetComponent<Rigidbody>();
        _colliders = GetComponentsInChildren<Collider>();
    }

    // Called by the bow when the arrow is placed on the string.
    public void Nock(Bow bow)
    {
        _bow = bow;
        _flying = false;
        _rb.isKinematic = true;
        SetCollidersEnabled(false);
    }

    public void Launch(Vector3 velocity)
    {
        transform.SetParent(null, true);
        _flying = true;
        _rb.isKinematic = false;
        _rb.useGravity = true;
        _rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        _rb.linearVelocity = velocity;
        SetCollidersEnabled(true);

        // The nock starts next to the archer's head, inside the player's body collider.
        // (Re-enabling a collider resets IgnoreCollision, so this must come after.)
        if (_bow != null)
            foreach (Collider own in _bow.transform.root.GetComponentsInChildren<Collider>())
                foreach (Collider c in _colliders)
                    Physics.IgnoreCollision(c, own);
        _destroyAt = Time.time + lifetimeIfMissed;
    }

    void Update()
    {
        if (_destroyAt > 0f && Time.time >= _destroyAt)
            Destroy(gameObject);
    }

    void FixedUpdate()
    {
        if (_flying && _rb.linearVelocity.sqrMagnitude > 0.01f)
            _rb.MoveRotation(Quaternion.LookRotation(_rb.linearVelocity, transform.up));
    }

    void OnCollisionEnter(Collision collision)
    {
        if (!_flying)
            return;

        _flying = false;
        Vector3 hitPoint = collision.GetContact(0).point;

        // Stick: freeze in place, slightly embedded along the flight direction.
        _rb.isKinematic = true;
        SetCollidersEnabled(false);
        transform.position = hitPoint - transform.forward * (length - penetrationDepth);

        // Follow moving targets (only when they have a Rigidbody, to avoid inheriting odd scales).
        if (collision.rigidbody != null)
            transform.SetParent(collision.transform, true);

        Target target = collision.collider.GetComponentInParent<Target>();
        if (target != null)
        {
            target.RegisterHit(hitPoint);
            if (_bow != null)
                _bow.OnArrowHitTarget();
        }

        _destroyAt = Time.time + lifetimeAfterHit;
    }

    void SetCollidersEnabled(bool on)
    {
        foreach (Collider c in _colliders)
            c.enabled = on;
    }

    // Builds a simple arrow from primitives: origin at the nock, pointing along +Z.
    public static Arrow CreateDefault()
    {
        const float length = 0.75f;
        var root = new GameObject("Arrow");

        GameObject shaft = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        shaft.name = "Shaft";
        shaft.transform.SetParent(root.transform, false);
        shaft.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
        shaft.transform.localPosition = new Vector3(0f, 0f, length * 0.5f);
        shaft.transform.localScale = new Vector3(0.01f, length * 0.5f, 0.01f);
        shaft.GetComponent<Renderer>().material.color = new Color(0.55f, 0.35f, 0.18f);

        GameObject tip = GameObject.CreatePrimitive(PrimitiveType.Cube);
        tip.name = "Tip";
        Object.Destroy(tip.GetComponent<Collider>());
        tip.transform.SetParent(root.transform, false);
        tip.transform.localPosition = new Vector3(0f, 0f, length);
        tip.transform.localRotation = Quaternion.Euler(0f, 0f, 45f);
        tip.transform.localScale = new Vector3(0.02f, 0.02f, 0.05f);
        tip.GetComponent<Renderer>().material.color = Color.gray;

        GameObject fletching = GameObject.CreatePrimitive(PrimitiveType.Cube);
        fletching.name = "Fletching";
        Object.Destroy(fletching.GetComponent<Collider>());
        fletching.transform.SetParent(root.transform, false);
        fletching.transform.localPosition = new Vector3(0f, 0f, 0.06f);
        fletching.transform.localScale = new Vector3(0.002f, 0.035f, 0.09f);
        fletching.GetComponent<Renderer>().material.color = Color.red;

        var rb = root.AddComponent<Rigidbody>();
        rb.mass = 0.05f;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.isKinematic = true;

        var arrow = root.AddComponent<Arrow>();
        arrow.length = length;
        return arrow;
    }
}
