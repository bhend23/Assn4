using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

// VR bow for Meta Quest (OVRInput).
// Hold the bow in one controller. Bring the other controller to the string,
// hold the trigger (or grip) to grab it, pull back, and let go to shoot.
// Arrow speed scales with how far the string was drawn.
//
// Without a headset (Editor play mode) hold the left mouse button to draw
// and release to fire along the bow's forward axis.
public class Bow : MonoBehaviour
{
    [Header("Hands")]
    public OVRInput.Controller bowHand = OVRInput.Controller.LTouch;
    public OVRInput.Controller stringHand = OVRInput.Controller.RTouch;
    [Tooltip("Transform that tracks the string hand, e.g. OVRCameraRig/.../RightControllerAnchor")]
    public Transform stringHandAnchor;

    [Header("Bow Parts")]
    public Transform topTip;
    public Transform bottomTip;
    [Tooltip("Where the string sits at rest (center of the string).")]
    public Transform nockRest;
    [Tooltip("Where the arrow rests on the bow grip. Arrows aim from the nock through this point.")]
    public Transform arrowRest;
    public LineRenderer stringLine;

    [Header("Draw")]
    [Tooltip("How close the string hand must be to the string to grab it (meters).")]
    public float grabRadius = 0.15f;
    [Tooltip("Maximum draw length (meters).")]
    public float maxDrawDistance = 0.6f;
    [Tooltip("Draw fraction (0-1) below which releasing does not fire.")]
    public float minDrawToFire = 0.1f;
    [Tooltip("Seconds to reach full draw when using the mouse fallback.")]
    public float desktopDrawTime = 1f;

    [Header("Arrow")]
    [Tooltip("Optional. If empty, a simple arrow is generated at runtime.")]
    public Arrow arrowPrefab;
    public float maxArrowSpeed = 45f;

    [Header("Haptics")]
    public float drawHapticStrength = 0.4f;
    public float releaseHapticStrength = 1f;
    public float releaseHapticDuration = 0.08f;

    public bool IsDrawing => _drawing;
    public float DrawAmount => _draw;

    bool _drawing;
    float _draw;
    Arrow _nockedArrow;
    Vector3 _nockPosition;
    float _hapticStopTime = -1f;
    bool _usingDesktopInput;

    void Start()
    {
        _usingDesktopInput = !OVRManager.isHmdPresent;
        if (stringLine != null)
        {
            stringLine.positionCount = 3;
            stringLine.useWorldSpace = true;
        }
        _nockPosition = nockRest.position;
    }

    void Update()
    {
        if (_usingDesktopInput)
            UpdateDesktopInput();
        else
            UpdateVRInput();

        if (_nockedArrow != null)
            PlaceNockedArrow();

        UpdateString();
        UpdateHaptics();
    }

    void UpdateVRInput()
    {
        if (stringHandAnchor == null)
            return;

        bool grabPressed = OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, stringHand)
                        || OVRInput.GetDown(OVRInput.Button.PrimaryHandTrigger, stringHand);
        bool grabHeld = OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, stringHand)
                     || OVRInput.Get(OVRInput.Button.PrimaryHandTrigger, stringHand);

        if (!_drawing && grabPressed &&
            Vector3.Distance(stringHandAnchor.position, nockRest.position) <= grabRadius)
        {
            BeginDraw();
        }

        if (!_drawing)
            return;

        if (!grabHeld)
        {
            Release();
            return;
        }

        // The nock follows the hand but can't be pulled past max draw or in front of the bow.
        Vector3 pull = stringHandAnchor.position - nockRest.position;
        if (Vector3.Dot(pull, transform.forward) > 0f)
            pull = Vector3.ProjectOnPlane(pull, transform.forward);
        pull = Vector3.ClampMagnitude(pull, maxDrawDistance);

        _nockPosition = nockRest.position + pull;
        _draw = Mathf.Clamp01(Vector3.Dot(-pull, transform.forward) / maxDrawDistance);
    }

    void UpdateDesktopInput()
    {
#if ENABLE_INPUT_SYSTEM
        Mouse mouse = Mouse.current;
        if (mouse == null)
            return;

        if (!_drawing && mouse.leftButton.wasPressedThisFrame)
            BeginDraw();

        if (!_drawing)
            return;

        if (!mouse.leftButton.isPressed)
        {
            Release();
            return;
        }

        _draw = Mathf.Clamp01(_draw + Time.deltaTime / desktopDrawTime);
        _nockPosition = nockRest.position - transform.forward * (_draw * maxDrawDistance);
#endif
    }

    void BeginDraw()
    {
        _drawing = true;
        _draw = 0f;
        _nockedArrow = arrowPrefab != null ? Instantiate(arrowPrefab) : Arrow.CreateDefault();
        _nockedArrow.Nock(this);
        PlayHaptic(stringHand, 0.3f, 0.05f);
    }

    void Release()
    {
        _drawing = false;

        if (_nockedArrow != null)
        {
            if (_draw >= minDrawToFire)
            {
                PlaceNockedArrow();
                _nockedArrow.Launch(AimDirection() * (maxArrowSpeed * _draw));
                PlayHaptic(stringHand, releaseHapticStrength, releaseHapticDuration);
                PlayHaptic(bowHand, releaseHapticStrength * 0.6f, releaseHapticDuration);
            }
            else
            {
                Destroy(_nockedArrow.gameObject);
            }
            _nockedArrow = null;
        }

        _draw = 0f;
        _nockPosition = nockRest.position;
    }

    Vector3 AimDirection()
    {
        Vector3 dir = arrowRest.position - _nockPosition;
        return dir.sqrMagnitude > 0.0001f ? dir.normalized : transform.forward;
    }

    void PlaceNockedArrow()
    {
        Vector3 dir = AimDirection();
        _nockedArrow.transform.SetPositionAndRotation(
            _nockPosition, Quaternion.LookRotation(dir, transform.up));
    }

    void UpdateString()
    {
        if (!_drawing)
            _nockPosition = nockRest.position;

        if (stringLine == null)
            return;
        stringLine.SetPosition(0, topTip.position);
        stringLine.SetPosition(1, _nockPosition);
        stringLine.SetPosition(2, bottomTip.position);
    }

    void UpdateHaptics()
    {
        if (_usingDesktopInput)
            return;

        if (_drawing)
        {
            // Rising tension buzz while holding the string.
            OVRInput.SetControllerVibration(0.2f + _draw * 0.3f, _draw * drawHapticStrength, stringHand);
        }
        else if (_hapticStopTime > 0f && Time.time >= _hapticStopTime)
        {
            OVRInput.SetControllerVibration(0f, 0f, stringHand);
            OVRInput.SetControllerVibration(0f, 0f, bowHand);
            _hapticStopTime = -1f;
        }
    }

    void PlayHaptic(OVRInput.Controller controller, float amplitude, float duration)
    {
        if (_usingDesktopInput)
            return;
        OVRInput.SetControllerVibration(1f, amplitude, controller);
        _hapticStopTime = Mathf.Max(_hapticStopTime, Time.time + duration);
    }

    public void OnArrowHitTarget()
    {
        PlayHaptic(bowHand, 0.5f, 0.05f);
    }

    void OnDisable()
    {
        if (!_usingDesktopInput)
        {
            OVRInput.SetControllerVibration(0f, 0f, stringHand);
            OVRInput.SetControllerVibration(0f, 0f, bowHand);
        }
    }

    void OnDrawGizmosSelected()
    {
        if (nockRest == null)
            return;
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(nockRest.position, grabRadius);
    }
}
