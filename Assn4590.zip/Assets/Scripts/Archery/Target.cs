using UnityEngine;
using UnityEngine.Events;

// Archery target. Scores hits by distance from the center:
// bullseye = ringCount * pointsPerRing, outer ring = pointsPerRing.
public class Target : MonoBehaviour
{
    [Tooltip("Center of the target face. Defaults to this transform.")]
    public Transform center;
    [Tooltip("Radius of the scoring face (meters).")]
    public float radius = 0.6f;
    public int ringCount = 5;
    public int pointsPerRing = 10;

    [Header("Feedback")]
    [Tooltip("Tinted on hit. Include every LOD renderer, since only one is drawn at a time.")]
    public Renderer[] flashRenderers;
    public Color flashColor = Color.white;
    public float flashDuration = 0.15f;
    public AudioSource hitSound;

    public UnityEvent<int> onHit;

    public int TotalScore { get; private set; }
    public int LastScore { get; private set; }

    Color[] _baseColors;
    float _flashUntil;

    void Awake()
    {
        if (center == null)
            center = transform;
        if (flashRenderers == null)
            flashRenderers = new Renderer[0];
        _baseColors = new Color[flashRenderers.Length];
        for (int i = 0; i < flashRenderers.Length; i++)
            _baseColors[i] = flashRenderers[i].material.color;
    }

    void Update()
    {
        if (_flashUntil > 0f && Time.time >= _flashUntil)
        {
            SetColor(null);
            _flashUntil = 0f;
        }
    }

    // null restores each renderer's original color.
    void SetColor(Color? color)
    {
        for (int i = 0; i < flashRenderers.Length; i++)
            flashRenderers[i].material.color = color ?? _baseColors[i];
    }

    public void RegisterHit(Vector3 worldPoint)
    {
        // Measure distance within the target's face plane (ignore depth).
        Vector3 offset = Vector3.ProjectOnPlane(worldPoint - center.position, center.forward);
        float normalized = offset.magnitude / radius;

        int ring = Mathf.Clamp(Mathf.FloorToInt(normalized * ringCount), 0, ringCount);
        LastScore = (ringCount - ring) * pointsPerRing;
        TotalScore += LastScore;

        Debug.Log($"[Target] Hit {name}: +{LastScore} (total {TotalScore})");

        SetColor(flashColor);
        _flashUntil = Time.time + flashDuration;
        if (hitSound != null)
            hitSound.Play();

        onHit?.Invoke(LastScore);
    }

    public void ResetScore()
    {
        TotalScore = 0;
        LastScore = 0;
    }

    void OnDrawGizmosSelected()
    {
        Transform c = center != null ? center : transform;
        Gizmos.color = Color.red;
        Gizmos.matrix = Matrix4x4.TRS(c.position, c.rotation, Vector3.one);
        for (int i = 1; i <= ringCount; i++)
        {
            float r = radius * i / ringCount;
            const int segments = 32;
            for (int s = 0; s < segments; s++)
            {
                float a0 = s * Mathf.PI * 2f / segments, a1 = (s + 1) * Mathf.PI * 2f / segments;
                Gizmos.DrawLine(new Vector3(Mathf.Cos(a0), Mathf.Sin(a0)) * r,
                                new Vector3(Mathf.Cos(a1), Mathf.Sin(a1)) * r);
            }
        }
    }
}
