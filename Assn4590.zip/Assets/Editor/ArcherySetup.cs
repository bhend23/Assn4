using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

// Tools > Archery > Set Up Bow and Target
// Puts the bow model (588863) on the left controller (string pulled with the right)
// and turns the target model (1344406) into a scoring target.
//
// The bow model has a string and an arrow baked into its mesh, so this splits it into
// a clean bow body (the string is drawn at runtime by a LineRenderer) and an arrow
// mesh that the Arrow prefab uses.
public static class ArcherySetup
{
    const string ArcheryFolder = "Assets/Scripts/Archery";
    const string BowModelPath = "Assets/MetaAssets/Prefabs/588863/588863_L.prefab";
    const string TargetModelPath = "Assets/MetaAssets/Prefabs/1344406/1344406_LODGroup.prefab";
    const string BowMeshPath = ArcheryFolder + "/Models/BowBody.asset";
    const string ArrowMeshPath = ArcheryFolder + "/Models/ArrowModel.asset";
    const string ArrowPrefabPath = ArcheryFolder + "/Prefabs/Arrow.prefab";

    // Bow model landmarks, measured in the prefab's space (2 m tall, pivot at the bottom,
    // the bow shoots toward -Z and the string sits on the +Z side).
    static readonly Vector3 GripCenter = new Vector3(0f, 1f, -0.45f);
    const float StringZ = 0.088f;
    const float StringTopY = 1.895f;
    const float StringBottomY = 0.103f;
    const float ArrowY = 1.014f;
    const float ArrowTailZ = -0.15f;  // behind this the "arrow" is the riser's ornament
    const float ArrowHeadZ = 0.33f;   // where the shaft ends and the head begins
    const float ArrowLength = 0.85f;  // shaft is stretched to this so a full draw fits
    const float BowScale = 0.6f; // 1.2 m tall in the hand

    // Target model: 2 m disc, pivot at the bottom, face normal along Z.
    const float TargetFaceCenterY = 1f;
    const float TargetScoringRadius = 0.8f; // outermost painted ring

    [MenuItem("Tools/Archery/Set Up Bow and Target")]
    internal static void SetUp()
    {
        OVRCameraRig rig = Object.FindFirstObjectByType<OVRCameraRig>();
        if (rig == null)
        {
            EditorUtility.DisplayDialog("Archery Setup", "No OVRCameraRig found in the open scene.", "OK");
            return;
        }

        Transform leftHand = FindChild(rig.transform, "LeftControllerAnchor");
        Transform rightHand = FindChild(rig.transform, "RightControllerAnchor");
        if (leftHand == null || rightHand == null)
        {
            EditorUtility.DisplayDialog("Archery Setup", "Couldn't find the controller anchors under the OVRCameraRig.", "OK");
            return;
        }

        Material modelMat = AssetDatabase.LoadAssetAtPath<GameObject>(BowModelPath).GetComponent<MeshRenderer>().sharedMaterial;
        BuildModelMeshes(out Mesh bowMesh, out Mesh arrowMesh, out float arrowLength);
        Arrow arrowPrefab = CreateArrowPrefab(arrowMesh, arrowLength, modelMat);

        foreach (Bow old in Object.FindObjectsByType<Bow>(FindObjectsInactive.Include))
            Undo.DestroyObjectImmediate(old.gameObject);
        GameObject bow = CreateBow(leftHand, rightHand, bowMesh, modelMat, arrowPrefab);
        Undo.RegisterCreatedObjectUndo(bow, "Create Bow");

        SetUpTarget(rig.transform);
        Selection.activeGameObject = bow;
    }

    // Splits the bow model's mesh into the bow body and the arrow by triangle position.
    static void BuildModelMeshes(out Mesh bowMesh, out Mesh arrowMesh, out float arrowLength)
    {
        GameObject model = AssetDatabase.LoadAssetAtPath<GameObject>(BowModelPath);
        Mesh source = model.GetComponent<MeshFilter>().sharedMesh;
        Matrix4x4 toModel = model.transform.localToWorldMatrix; // prefab import rotation/scale

        Vector3[] verts = source.vertices;
        for (int i = 0; i < verts.Length; i++)
            verts[i] = toModel.MultiplyPoint3x4(verts[i]);

        var bowTris = new List<int>();
        var arrowTris = new List<int>();
        int[] tris = source.triangles;
        for (int i = 0; i < tris.Length; i += 3)
        {
            Vector3 a = verts[tris[i]], b = verts[tris[i + 1]], d = verts[tris[i + 2]];
            Vector3 c = (a + b + d) / 3f;
            // Where the shaft crosses the baked string: string triangles are long in Y, shaft ones in Z.
            Vector3 size = Vector3.Max(a, Vector3.Max(b, d)) - Vector3.Min(a, Vector3.Min(b, d));
            bool crossesString = c.z > 0.055f && c.z < 0.125f && size.y > 0.005f && size.y > size.z;
            bool arrow = Mathf.Abs(c.y - ArrowY) < 0.05f && c.z > ArrowTailZ && !crossesString;
            bool stringPart = c.z > 0.055f;
            if (arrow)
                arrowTris.AddRange(new[] { tris[i], tris[i + 1], tris[i + 2] });
            else if (!stringPart)
                bowTris.AddRange(new[] { tris[i], tris[i + 1], tris[i + 2] });
        }

        // Arrow: nock at the origin, head along +Z. The model's arrow already points +Z.
        float nockZ = float.MaxValue, headZ = float.MinValue;
        foreach (int i in arrowTris)
        {
            nockZ = Mathf.Min(nockZ, verts[i].z);
            headZ = Mathf.Max(headZ, verts[i].z);
        }
        // Lengthen the shaft only, leaving the head undistorted.
        float stretch = (ArrowLength - (headZ - ArrowHeadZ)) / (ArrowHeadZ - nockZ);
        Vector3[] arrowVerts = (Vector3[])verts.Clone();
        foreach (int i in arrowTris)
            if (verts[i].z < ArrowHeadZ)
                arrowVerts[i].z = ArrowHeadZ + (verts[i].z - ArrowHeadZ) * stretch;
        nockZ = ArrowHeadZ + (nockZ - ArrowHeadZ) * stretch;
        arrowLength = headZ - nockZ;
        Vector3 arrowOrigin = new Vector3(0f, ArrowY, nockZ);
        arrowMesh = ExtractMesh(source, toModel, arrowVerts, arrowTris, "ArrowModel",
                                Quaternion.identity, arrowOrigin);

        // Bow: grip at the origin, turned 180 degrees so it shoots along +Z.
        bowMesh = ExtractMesh(source, toModel, verts, bowTris, "BowBody",
                              Quaternion.Euler(0f, 180f, 0f), GripCenter);

        SaveMesh(bowMesh, BowMeshPath);
        SaveMesh(arrowMesh, ArrowMeshPath);
        bowMesh = AssetDatabase.LoadAssetAtPath<Mesh>(BowMeshPath);
        arrowMesh = AssetDatabase.LoadAssetAtPath<Mesh>(ArrowMeshPath);
    }

    // Copies the given triangles into a new mesh, transformed by rotation * (p - origin).
    static Mesh ExtractMesh(Mesh source, Matrix4x4 toModel, Vector3[] modelVerts, List<int> tris,
                            string name, Quaternion rotation, Vector3 origin)
    {
        Vector3[] normals = source.normals;
        Vector4[] tangents = source.tangents;
        Vector2[] uvs = source.uv;
        Quaternion normalRot = rotation * toModel.rotation;

        var remap = new Dictionary<int, int>();
        var v = new List<Vector3>();
        var n = new List<Vector3>();
        var t = new List<Vector4>();
        var uv = new List<Vector2>();
        var indices = new List<int>(tris.Count);
        foreach (int i in tris)
        {
            if (!remap.TryGetValue(i, out int j))
            {
                j = v.Count;
                remap[i] = j;
                v.Add(rotation * (modelVerts[i] - origin));
                if (normals.Length > 0) n.Add(normalRot * normals[i]);
                if (tangents.Length > 0)
                {
                    Vector3 tan = normalRot * (Vector3)tangents[i];
                    t.Add(new Vector4(tan.x, tan.y, tan.z, tangents[i].w));
                }
                if (uvs.Length > 0) uv.Add(uvs[i]);
            }
            indices.Add(j);
        }

        var mesh = new Mesh { name = name };
        FillMesh(mesh, v, n, t, uv, indices);
        return mesh;
    }

    static void FillMesh(Mesh mesh, List<Vector3> v, List<Vector3> n, List<Vector4> t, List<Vector2> uv, List<int> indices)
    {
        mesh.Clear();
        mesh.SetVertices(v);
        if (n.Count > 0) mesh.SetNormals(n);
        if (t.Count > 0) mesh.SetTangents(t);
        if (uv.Count > 0) mesh.SetUVs(0, uv);
        mesh.SetTriangles(indices, 0);
        mesh.RecalculateBounds();
    }

    static void SaveMesh(Mesh mesh, string path)
    {
        EnsureFolder(System.IO.Path.GetDirectoryName(path));
        Mesh existing = AssetDatabase.LoadAssetAtPath<Mesh>(path);
        if (existing != null)
        {
            // Refill in place to keep the GUID. (CopySerialized would leave stale GPU buffers.)
            var v = new List<Vector3>(); var n = new List<Vector3>(); var t = new List<Vector4>(); var uv = new List<Vector2>();
            mesh.GetVertices(v); mesh.GetNormals(n); mesh.GetTangents(t); mesh.GetUVs(0, uv);
            FillMesh(existing, v, n, t, uv, new List<int>(mesh.triangles));
            Object.DestroyImmediate(mesh);
            EditorUtility.SetDirty(existing);
        }
        else
        {
            AssetDatabase.CreateAsset(mesh, path);
        }
        AssetDatabase.SaveAssets();
    }

    static Arrow CreateArrowPrefab(Mesh mesh, float length, Material mat)
    {
        var root = new GameObject("Arrow");
        var visual = new GameObject("Model");
        visual.transform.SetParent(root.transform, false);
        visual.AddComponent<MeshFilter>().sharedMesh = mesh;
        visual.AddComponent<MeshRenderer>().sharedMaterial = mat;

        var col = root.AddComponent<CapsuleCollider>();
        col.direction = 2; // Z
        col.radius = 0.01f;
        col.height = length;
        col.center = new Vector3(0f, 0f, length * 0.5f);

        var rb = root.AddComponent<Rigidbody>();
        rb.mass = 0.05f;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.isKinematic = true;

        root.AddComponent<Arrow>().length = length;

        EnsureFolder(System.IO.Path.GetDirectoryName(ArrowPrefabPath));
        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(root, ArrowPrefabPath);
        Object.DestroyImmediate(root);
        return prefab.GetComponent<Arrow>();
    }

    static GameObject CreateBow(Transform bowHand, Transform stringHand, Mesh mesh, Material mat, Arrow arrowPrefab)
    {
        var bow = new GameObject("Bow");
        bow.transform.SetParent(bowHand, false);

        var model = new GameObject("Model");
        model.transform.SetParent(bow.transform, false);
        model.transform.localScale = Vector3.one * BowScale;
        model.AddComponent<MeshFilter>().sharedMesh = mesh;
        model.AddComponent<MeshRenderer>().sharedMaterial = mat;

        Transform topTip = Empty("TopTip", bow.transform, BowPoint(new Vector3(0f, StringTopY, StringZ)));
        Transform bottomTip = Empty("BottomTip", bow.transform, BowPoint(new Vector3(0f, StringBottomY, StringZ)));
        Transform nockRest = Empty("NockRest", bow.transform, BowPoint(new Vector3(0f, ArrowY, StringZ)));
        Transform arrowRest = Empty("ArrowRest", bow.transform, BowPoint(new Vector3(0f, ArrowY, GripCenter.z)));

        LineRenderer line = bow.AddComponent<LineRenderer>();
        line.sharedMaterial = GetStringMaterial();
        line.widthMultiplier = 0.005f;
        line.numCapVertices = 2;
        line.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        line.positionCount = 3;
        line.useWorldSpace = true;
        line.SetPositions(new[] { topTip.position, nockRest.position, bottomTip.position });

        Bow b = bow.AddComponent<Bow>();
        b.stringHandAnchor = stringHand;
        b.topTip = topTip;
        b.bottomTip = bottomTip;
        b.nockRest = nockRest;
        b.arrowRest = arrowRest;
        b.stringLine = line;
        b.arrowPrefab = arrowPrefab;
        // Arrow must still reach past the grip at full draw.
        b.maxDrawDistance = Mathf.Min(0.5f, arrowPrefab.length - nockRest.localPosition.magnitude - 0.05f);
        return bow;
    }

    // Converts a point in the bow model's prefab space to the Bow object's local space.
    static Vector3 BowPoint(Vector3 modelPoint)
    {
        return Quaternion.Euler(0f, 180f, 0f) * (modelPoint - GripCenter) * BowScale;
    }

    // Uses the target model already in the scene, or places one 8 m in front of the rig.
    static void SetUpTarget(Transform rig)
    {
        GameObject targetModel = AssetDatabase.LoadAssetAtPath<GameObject>(TargetModelPath);
        GameObject target = null;
        Target existing = Object.FindFirstObjectByType<Target>();
        if (existing != null)
            target = existing.gameObject;
        foreach (GameObject root in rig.gameObject.scene.GetRootGameObjects())
            if (target == null && PrefabUtility.GetCorrespondingObjectFromSource(root) == targetModel)
                target = root;

        if (target == null)
        {
            target = (GameObject)PrefabUtility.InstantiatePrefab(targetModel, rig.gameObject.scene);
            Vector3 forward = Vector3.ProjectOnPlane(rig.forward, Vector3.up).normalized;
            target.transform.SetPositionAndRotation(
                new Vector3(rig.position.x, 0f, rig.position.z) + forward * 8f,
                Quaternion.LookRotation(-forward));
            Undo.RegisterCreatedObjectUndo(target, "Create Target");
        }
        target.name = "Target";

        // Collider on the full-detail mesh; it stays active whichever LOD is drawn.
        MeshRenderer[] renderers = target.GetComponentsInChildren<MeshRenderer>();
        MeshRenderer lod0 = renderers[0];
        if (lod0.GetComponent<Collider>() == null)
            Undo.AddComponent<MeshCollider>(lod0.gameObject).sharedMesh = lod0.GetComponent<MeshFilter>().sharedMesh;

        Transform center = target.transform.Find("Center");
        if (center == null)
        {
            center = Empty("Center", target.transform, Vector3.zero);
            Undo.RegisterCreatedObjectUndo(center.gameObject, "Create Target Center");
        }
        center.localPosition = new Vector3(0f, TargetFaceCenterY, 0f);
        center.localRotation = Quaternion.identity;

        Target t = target.GetComponent<Target>();
        if (t == null)
            t = Undo.AddComponent<Target>(target);
        t.center = center;
        t.radius = TargetScoringRadius * target.transform.lossyScale.x;
        t.flashRenderers = renderers;
        t.flashColor = new Color(1f, 0.85f, 0.4f);
        EditorUtility.SetDirty(t);
    }

    // Unlit: a LineRenderer has no normals, so a lit string can render black on Quest.
    static Material GetStringMaterial()
    {
        const string path = ArcheryFolder + "/Materials/BowString.mat";
        Shader unlit = Shader.Find("Universal Render Pipeline/Unlit");
        Material mat = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (mat == null)
        {
            EnsureFolder(ArcheryFolder + "/Materials");
            mat = new Material(unlit);
            AssetDatabase.CreateAsset(mat, path);
        }
        mat.shader = unlit;
        mat.SetColor("_BaseColor", new Color(0.85f, 0.8f, 0.7f));
        EditorUtility.SetDirty(mat);
        return mat;
    }

    static Transform Empty(string name, Transform parent, Vector3 localPos)
    {
        var t = new GameObject(name).transform;
        t.SetParent(parent, false);
        t.localPosition = localPos;
        return t;
    }

    static void EnsureFolder(string folder)
    {
        folder = folder.Replace('\\', '/');
        if (AssetDatabase.IsValidFolder(folder))
            return;
        EnsureFolder(System.IO.Path.GetDirectoryName(folder));
        AssetDatabase.CreateFolder(System.IO.Path.GetDirectoryName(folder).Replace('\\', '/'),
                                   System.IO.Path.GetFileName(folder));
    }

    static Transform FindChild(Transform root, string name)
    {
        foreach (Transform t in root.GetComponentsInChildren<Transform>(true))
            if (t.name == name)
                return t;
        return null;
    }
}
