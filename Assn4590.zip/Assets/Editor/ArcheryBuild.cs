using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

// Command-line build for the Quest:
//   Unity -batchmode -quit -projectPath . -executeMethod ArcheryBuild.BuildQuest
// Adds the bow and target to the scene if they're missing, then builds build/Archery.apk.
public static class ArcheryBuild
{
    const string ScenePath = "Assets/Scenes/SampleScene.unity";
    const string ApkPath = "build/Archery.apk";

    [MenuItem("Tools/Archery/Build Quest APK")]
    public static void BuildQuest()
    {
        EditorSceneManager.OpenScene(ScenePath);
        if (Object.FindFirstObjectByType<Bow>() == null)
        {
            ArcherySetup.SetUp();
            EditorSceneManager.SaveOpenScenes();
        }

        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
        BuildReport report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
        {
            scenes = new[] { ScenePath },
            locationPathName = ApkPath,
            target = BuildTarget.Android,
            options = EditorUserBuildSettings.development ? BuildOptions.Development : BuildOptions.None,
        });

        Debug.Log($"[ArcheryBuild] {report.summary.result}: {ApkPath} ({report.summary.totalErrors} errors)");
        if (Application.isBatchMode && report.summary.result != BuildResult.Succeeded)
            EditorApplication.Exit(1);
    }
}
